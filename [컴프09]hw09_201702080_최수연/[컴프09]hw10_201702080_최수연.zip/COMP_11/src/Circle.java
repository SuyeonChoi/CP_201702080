 
public class Circle extends Shape {

	public int area() {
		return width*width * (int) Math.PI;
	}
}