
public class Triangle extends Shape {
	public int area() {
		return (width * height) / 2;
	}
}
