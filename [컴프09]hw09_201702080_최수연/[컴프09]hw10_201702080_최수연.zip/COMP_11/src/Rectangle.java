
public class Rectangle extends Shape {
	
	public int area() {
		return width * height;
	}
}